export const BASE_URL= "http://54.200.253.9:3777/api/v1"
